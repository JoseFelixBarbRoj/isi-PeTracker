from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from werkzeug.utils import secure_filename
from pathlib import Path
from model import predict
from collections import deque
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from math import radians, cos, sin, sqrt, atan2

def haversine(lat1, lon1, lat2, lon2):
    R = 6371.0
    lat1, lon1, lat2, lon2 = map(radians, [float(lat1), float(lon1), float(lat2), float(lon2)])
    dlat = lat2 - lat1
    dlon = lon2 - lon1

    a = sin(dlat/2)**2 + cos(lat1)*cos(lat2)*sin(dlon/2)**2
    c = 2*atan2(sqrt(a), sqrt(1-a))
    return R * c

app = Flask(__name__, 
            template_folder=Path("../frontend/templates"),
            static_folder=Path("../frontend/static"))

app.config["SQLALCHEMY_DATABASE_URI"] = (
    "mysql+pymysql://root:1234@localhost:3306/perros_app"
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)
with app.app_context():
    db.create_all()


class ShelterReport(db.Model):
    __tablename__ = "shelter_reports"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    relative_path = db.Column(db.String(255), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.now())
    shelter_name = db.Column(db.String(50), nullable=False)

app.secret_key = "super-secret-key"  # Provisional

UPLOAD_FOLDER = Path("uploads")
UPLOAD_FOLDER.mkdir(exist_ok=True, parents=True)
SHELTER_UPLOAD_FOLDER = Path("shelter_uploads")
SHELTER_UPLOAD_FOLDER.mkdir(exist_ok=True, parents=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["SHELTER_UPLOAD_FOLDER"] = SHELTER_UPLOAD_FOLDER

# Lo reemplazaré por la base de datos
USERS = {
    "admin": "1234",
    "user": "password"
}

SHELTERS = {
    "shelter": "1234",
    "safe_haven": "dogs123"
}

REPORTS = deque(maxlen=10)
PROTECTED_REPORTS = deque(maxlen=100)

@app.route("/")
def index():
    return render_template("choose_login.html")

@app.route("/login/user", methods=["GET", "POST"])
def login_user():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if USERS.get(username) == password:
            session["user"] = username
            session["role"] = "user"
            return redirect(url_for("upload")) 
        else:
            return render_template("login_user.html", error="Invalid credentials")

    return render_template("login_user.html")

@app.route("/upload", methods=["GET"])
def upload():
    if session.get("role") != "user":
        return redirect(url_for("login_user"))
    return render_template("upload.html")


@app.route("/predict", methods=["POST"])
def predict_image():
    if "user" not in session:
        return jsonify({"error": "Unauthorized"}), 401

    username = session["user"]
    file = request.files["image"]
    original_name = secure_filename(file.filename)
    user_folder = UPLOAD_FOLDER / username
    user_folder.mkdir(exist_ok=True, parents=True)
    timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    suffix = Path(original_name).suffix
    stem = Path(original_name).stem       
    unique_filename = f"{stem}_{timestamp_str}{suffix}"
    file_path = user_folder / unique_filename
    file.save(file_path)

    latitude = request.form.get("latitude")
    longitude = request.form.get("longitude")
    category = predict(file_path)  

    report = {
        "category": category,
        "latitude": latitude,
        "longitude": longitude,
        "timestamp": timestamp_str,
        "username": session["user"],
        "filename": str(file_path)
    }

    REPORTS.append(report)
    nearby_protected = [
        r for r in PROTECTED_REPORTS
        if r["category"] == category and haversine(latitude, longitude, r["latitude"], r["longitude"]) <= 10
    ]
    return jsonify({
        "current": report,
        "reports": list(REPORTS),
        "nearby_protected": nearby_protected
    })

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/login/shelter", methods=["GET", "POST"])
def login_shelter():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if SHELTERS.get(username) == password:
            session["user"] = username
            session["role"] = "shelter"
            return redirect(url_for("shelter_dashboard"))
        else:
            return render_template("login_shelter.html", error="Invalid credentials")

    return render_template("login_shelter.html")

@app.route("/shelter/dashboard") 
def shelter_dashboard(): 
    if session.get("role") != "shelter": 
        return redirect(url_for("login_shelter")) 
    return "Shelter dashboard"
@app.route("/shelter/report", methods=["GET", "POST"])

def shelter_report():
    if session.get("role") != "shelter":
        return redirect(url_for("login_shelter"))

    if request.method == "POST":
        file = request.files["image"]
        if not file:
            return "No file uploaded", 400

        latitude = float(request.form.get("latitude"))
        longitude = float(request.form.get("longitude"))

        shelter_name = session["user"]
        shelter_folder = SHELTER_UPLOAD_FOLDER / shelter_name
        shelter_folder.mkdir(exist_ok=True, parents=True)

        original_name = secure_filename(file.filename)
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        stem = Path(original_name).stem
        suffix = Path(original_name).suffix
        unique_filename = f"{stem}_{timestamp_str}{suffix}"

        file_path = shelter_folder / unique_filename
        file.save(file_path)

        category = predict(file_path)

        relative_path = file_path.relative_to(Path.cwd())
        report = ShelterReport(
            relative_path=str(relative_path),
            category=category,
            latitude=latitude,
            longitude=longitude,
            shelter_name=shelter_name
        )
        db.session.add(report)
        db.session.commit()

        return jsonify({
            "message": "Protected dog report saved",
            "category": category,
            "latitude": latitude,
            "longitude": longitude,
            "relative_path": str(relative_path),
            "timestamp": timestamp_str,
            "shelter": session["user"]
        })

    return render_template("shelter_report.html")

@app.route("/shelter/map")
def shelter_map():
    if session.get("role") != "shelter":
        return redirect(url_for("login_shelter"))

    reports = ShelterReport.query.order_by(ShelterReport.timestamp.desc()).limit(10).all()
    return render_template("shelter_map.html", reports=reports)

if __name__ == "__main__":
    app.run(debug=True)
