from backend.inference.efficientnet_v2_s import EfficientNetV2
from pathlib import Path
import torch

def predict(image_path):
    model = EfficientNetV2(num_classes=18)
    model_path = Path(__file__).parent / 'inference' / 'models' / 'best.pth'
    model.load_state_dict(torch.load(model_path, map_location='cpu'))
    model.eval()
    with torch.inference_mode():
        image = torch.load(image_path).unsqueeze(0)
        logits = model(image)
        predicted_class = logits.softmax(dim=1).argmax(dim=1).item()
    return predicted_class